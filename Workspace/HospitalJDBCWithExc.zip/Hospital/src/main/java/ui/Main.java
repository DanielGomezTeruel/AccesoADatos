package ui;


import domain.exceptions.PatientDBException;
import domain.model.CredentialDTO;
import domain.model.MedRecordDTO;
import domain.model.PatientDTO;
import jakarta.enterprise.inject.se.SeContainer;
import jakarta.enterprise.inject.se.SeContainerInitializer;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    static void main() {
        SeContainerInitializer initializer = SeContainerInitializer.newInstance();
        final SeContainer container = initializer.initialize();

        PatientUI patientUI = container.select(PatientUI.class).get();
        CredentialsUI credentialsUI = container.select(CredentialsUI.class).get();
        DoctorUI doctorUI = container.select(DoctorUI.class).get();
        MedRecordUI medRecordUI = container.select(MedRecordUI.class).get();


        Scanner sc = new Scanner(System.in);
        for (boolean bucleCred = true; bucleCred; ) {
            System.out.println("Username:");
            String username = sc.nextLine();
            System.out.println("Password:");
            String password = sc.nextLine();
            CredentialDTO tempCred = new CredentialDTO(username, password);
            if (credentialsUI.login(tempCred)) {
                System.out.println("Welcome, " + username);
                bucleCred = false;
            } else {
                System.out.println("Wrong credentials");
            }
        }
            for (boolean bucle = true; bucle; ) {
                IO.println("""
                        1. Get all patients
                        2. Add Patient
                        3. Update Patient
                        4. Delete Patient
                        5. Get all Doctors
                        6. Get all MedRecords by patient
                        7. Add MedRecord
                        8. Update MedRecord
                        9. Delete MedRecord
                        10. Exit
                        """);
                switch (sc.nextInt()) {
                    case 1:
                        try {
                            IO.println(patientUI.getAll());
                        }catch(PatientDBException e){
                            Logger.getLogger(Main.class.getName()).log(Level.SEVERE,e.getMessage());
                            e.printStackTrace();
                        }
                        break;
                    case 2:
                        IO.println("ID:");
                        int id = sc.nextInt();
                        sc.nextLine();
                        IO.println("Name:");
                        String name = sc.nextLine();
                        IO.println("---Birth date (all in numbers, add a zero if its a single digit)---");
                        IO.println("Day:");
                        String day = sc.nextLine();
                        IO.println("Month:");
                        String month = sc.nextLine();
                        IO.println("Year:");
                        String year = sc.nextLine();
                        IO.println("Phone:");
                        String phone = sc.nextLine();
                        patientUI.add(new PatientDTO(id, name, LocalDate.parse(year + "-" + month + "-" + day), phone, 0, null, null));
                        break;
                    case 3:
                        patientUI.update(new PatientDTO(1,null,null,"69696969",0,null,null));
                        break;
                    case 4:
                        System.out.println("ID:");
                        patientUI.delete(sc.nextInt());
                        break;
                    case 5:
                        IO.println(doctorUI.getAll());
                        break;
                    case 6:
                        IO.println(medRecordUI.getAllbyPatientId(1));
                        break;
                    case 7:
                        medRecordUI.add(new MedRecordDTO(1, "desc", "2025-12-10", 1, 2, List.of()));
                        break;
                    case 8:
                        medRecordUI.update(new MedRecordDTO(1, "description", "2024-12-11", 1, 2, List.of()));
                        break;
                    case 9:
                        medRecordUI.delete(1);
                        break;
                    case 10:
                        bucle = false;
                        break;
                }
            }
        }
    }



