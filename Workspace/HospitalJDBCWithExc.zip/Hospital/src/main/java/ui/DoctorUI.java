package ui;


import domain.model.DoctorDTO;

import domain.service.DoctorService;
import jakarta.inject.Inject;

import java.util.List;

public class DoctorUI {

    private final DoctorService doctorService;


    @Inject
    public DoctorUI(DoctorService doctorService){
        this.doctorService=doctorService;
    }

    public List<DoctorDTO> getAll(){
        return doctorService.getAll();
    }

    public void add(DoctorDTO doctorDTO){
        doctorService.add(doctorDTO);
    }

    public void update(DoctorDTO doctorDTO){doctorService.update(doctorDTO);}

    public void delete(int idDelete){doctorService.delete(idDelete);}
}
