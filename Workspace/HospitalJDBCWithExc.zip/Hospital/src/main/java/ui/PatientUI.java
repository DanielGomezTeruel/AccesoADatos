package ui;

import domain.service.PatientService;
import jakarta.inject.Inject;
import domain.model.PatientDTO;

import java.util.List;





public class PatientUI {
    private final PatientService patientService;


    @Inject
    public PatientUI(PatientService patientService){
        this.patientService=patientService;
    }



    public List<PatientDTO> getAll(){

        return patientService.getAll();

    }

    public void add(PatientDTO patientDTO){
        patientService.add(patientDTO);
    }

    public void update(PatientDTO patientDTO){patientService.update(patientDTO);}

    public void delete(int idDelete){patientService.delete(idDelete);}


}
