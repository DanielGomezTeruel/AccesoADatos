package domain.mappers;


import dao.model.Patient;
import domain.model.PatientDTO;

public class PatientDTOMapper {
    public Patient dtoToEntity(PatientDTO patientDTO) {

        return new Patient(patientDTO.getId(),patientDTO.getName(),patientDTO.getBirthDate(),patientDTO.getPhone());

    }

    public PatientDTO entityToDto(Patient patient1) {
        return new PatientDTO(patient1.getId(),patient1.getName(),
                patient1.getBirthDate(),patient1.getPhone(),0,null,null);
    }

}
