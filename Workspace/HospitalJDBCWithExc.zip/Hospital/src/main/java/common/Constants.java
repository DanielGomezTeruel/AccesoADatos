package common;

public class Constants {

    public static final String DATABASE_ERROR = "Database Error";
    public static final String CREDENTIAL_DB_ERROR = "Credential DB Error";
    public static final String PATIENT_DB_ERROR = "Patient DB Error";
}
