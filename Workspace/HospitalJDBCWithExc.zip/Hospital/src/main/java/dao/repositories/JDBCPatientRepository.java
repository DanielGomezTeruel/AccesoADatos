package dao.repositories;

import dao.PatientRepository;
import dao.common.DBConnection;
import dao.mappers.PatientSQLMapper;
import dao.model.Patient;
import dao.common.SQLQueries;
import domain.exceptions.PatientDBException;
import jakarta.inject.Inject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JDBCPatientRepository implements PatientRepository{
    List<Patient> patients = new ArrayList<>();

    private final DBConnection db;
    private final PatientSQLMapper patientSQLMapper;

    @Inject
    public JDBCPatientRepository(DBConnection db, PatientSQLMapper patientSQLMapper) {
        this.db = db;
        this.patientSQLMapper = patientSQLMapper;
    }

    @Override
    public List<Patient> getAll() {
        try (Connection con = db.getConnection();
             Statement statement = con.createStatement()) {

            ResultSet rs = statement.executeQuery(SQLQueries.SELECT_patients_QUERY);
            patients=patientSQLMapper.mapPatient(rs);

        } catch (SQLException ex) {
            Logger.getLogger(JDBCPatientRepository.class.getName()).log(Level.SEVERE, null, ex);
            throw new PatientDBException();
        }
        return patients;
    }

    @Override
    public int add(Patient patient){
        int id=0;
        try (Connection con = db.getConnection();
             PreparedStatement preparedStatement = con.prepareStatement(SQLQueries.INSERT_patient, Statement.RETURN_GENERATED_KEYS)){
            preparedStatement.setString(1, patient.getName());
            preparedStatement.setDate(2, Date.valueOf(patient.getBirthDate()));
            preparedStatement.setString(3, patient.getPhone());

            int rowsAffected= preparedStatement.executeUpdate();
            ResultSet rs = preparedStatement.getGeneratedKeys();
            if(rs.next()) {
                id = rs.getInt(1);
            }

        }catch (SQLException ex) {
            Logger.getLogger(JDBCPatientRepository.class.getName()).log(Level.SEVERE, null, ex);
            throw new PatientDBException();
        }
        return id;
    }

    @Override
    public void update(Patient patient) {
        try (Connection con = db.getConnection();
             PreparedStatement preparedStatement = con.prepareStatement(SQLQueries.UPDATE_PATIENT_PHONE)) {
            preparedStatement.setString(1, patient.getPhone());
            preparedStatement.setInt(2, patient.getId());

            preparedStatement.executeUpdate();


        } catch (SQLException sqle) {
            Logger.getLogger(JDBCPatientRepository.class.getName()).log(Level.SEVERE, null, sqle);
            throw new PatientDBException();
        }
    }

    @Override
    public void delete(int idDelete) {
        try (Connection con = db.getConnection();
             PreparedStatement preparedStatement = con.prepareStatement(SQLQueries.DELETE_patient)) {
            preparedStatement.setInt(1, idDelete);
            preparedStatement.executeUpdate();

        } catch (SQLException sqle) {
            Logger.getLogger(JDBCPatientRepository.class.getName()).log(Level.SEVERE, null, sqle);
        }
    }

    public Patient get(int id){
        return getAll().stream().filter(patient -> patient.getId()==id).findFirst().orElse(null);
    }




}
