package dao.repositories;

import dao.DoctorRepository;
import dao.common.DBConnection;
import dao.common.SQLQueries;
import dao.mappers.DoctorSQLMapper;
import dao.model.Doctor;
import jakarta.inject.Inject;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JDBCDoctorRepository implements DoctorRepository {
    List<Doctor> doctors = new ArrayList<>();

    private final DBConnection db;
    private final DoctorSQLMapper doctorSQLMapper;

    @Inject
    public JDBCDoctorRepository(DBConnection db, DoctorSQLMapper doctorSQLMapper) {
        this.db = db;
        this.doctorSQLMapper = doctorSQLMapper;
    }

    @Override
    public List<Doctor> getAll() {
        try (Connection con = db.getConnection();
             Statement statement = con.createStatement()) {

            ResultSet rs = statement.executeQuery(SQLQueries.SELECT_doctors_QUERY);
            doctors=doctorSQLMapper.mapDoctor(rs);

        } catch (SQLException ex) {
            Logger.getLogger(JDBCPatientRepository.class.getName()).log(Level.SEVERE, null, ex);
            //Throw exception?
        }
        return doctors;
    }

    @Override
    public int add(Doctor doctor) {
        return 0;
    }

    @Override
    public void update(Doctor doctorDatabase) {
        System.out.println("Doctor updated");
    }

    @Override
    public void delete(int idDelete) {
        System.out.println("Doctor deleted");
    }
}
