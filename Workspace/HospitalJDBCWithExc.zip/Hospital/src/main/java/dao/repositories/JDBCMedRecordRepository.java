package dao.repositories;

import dao.MedRecordRepository;
import dao.model.MedRecord;

import java.util.List;

public class JDBCMedRecordRepository implements MedRecordRepository {
    @Override
    public List<MedRecord> getAllbyPatientId(int idPatient) {
        System.out.println("MedRecord getAllByPatient");
        return List.of();
    }

    @Override
    public int add(MedRecord medRecord) {
        System.out.println("MedRecord added");
        return 0;
    }

    @Override
    public void update(MedRecord medRecordDatabase) {
        System.out.println("MedRecord updated");
    }

    @Override
    public void delete(int idDelete) {
        System.out.println("MedRecord deleted");
    }
}
