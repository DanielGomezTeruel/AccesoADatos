package dao.common;

public class SQLQueries {

    public static final String SELECT_patients_QUERY = "select * from patients";
    public static final String SELECT_doctors_QUERY = "select * from doctors";
    public static final String SELECT_getCredentials_QUERY = "selecsst * from user_login where username= ?";
    public static final String INSERT_patient = "INSERT INTO patients (name, date_of_birth, phone) VALUES (?,?,?)";
    public static final String DELETE_patient = "delete from patients where patient_id = ?";
    public static final String UPDATE_PATIENT_PHONE = "update patients set phone = ? where patient_id = ?";

}
