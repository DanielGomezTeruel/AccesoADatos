package ui;

import domain.service.CredentialService;
import jakarta.inject.Inject;

import java.util.Scanner;

public class CredentialsUI {
    private final CredentialService credentialService;

    @Inject
    public CredentialsUI(CredentialService credentialService){
        this.credentialService=credentialService;
    }

}