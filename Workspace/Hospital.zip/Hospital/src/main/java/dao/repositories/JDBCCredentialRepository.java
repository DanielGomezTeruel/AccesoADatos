package dao.repositories;

import dao.CredentialRepository;
import dao.model.Credentials;

import java.util.ArrayList;
import java.util.List;


public class JDBCCredentialRepository implements CredentialRepository {
    private List<Credentials> credentials = new ArrayList<>();

    @Override
    public Credentials getByUsername(String username){
        credentials.add(new Credentials(0,"root", "quevedo2dam"));
        return credentials.stream().filter(credential -> credential.getUsername().equals(username)).findFirst().orElse(null);
    }


    @Override
    public int add(Credentials credentials) {
        return 0;
    }

    @Override
    public void update(Credentials credentialsDatabase) {

    }

    @Override
    public void delete(int idDelete) {

    }
}
