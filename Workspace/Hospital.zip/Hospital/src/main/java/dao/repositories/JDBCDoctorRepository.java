package dao.repositories;

import dao.DoctorRepository;
import dao.model.Doctor;

import java.util.List;

public class JDBCDoctorRepository implements DoctorRepository {
    @Override
    public List<Doctor> getAll() {
        System.out.println("Doctor getAll()");
        return List.of();
    }

    @Override
    public int add(Doctor doctor) {
        return 0;
    }

    @Override
    public void update(Doctor doctorDatabase) {
        System.out.println("Doctor updated");
    }

    @Override
    public void delete(int idDelete) {
        System.out.println("Doctor deleted");
    }
}
