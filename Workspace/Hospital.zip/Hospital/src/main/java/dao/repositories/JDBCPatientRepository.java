package dao.repositories;

import dao.PatientRepository;
import dao.model.Patient;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class JDBCPatientRepository implements PatientRepository{
    List<Patient> patients = new ArrayList<>();

    @Override
    public List<Patient> getAll(){

     patients.add(new Patient(1,"Paco", LocalDate.parse("2001-02-24"),"612-324-111"));
     patients.add(new Patient(2,"Pepe", LocalDate.parse("2002-03-16"),"653-335-121"));
     patients.add(new Patient(3,"Juan", LocalDate.parse("2004-04-09"),"644-987-113"));
     patients.add(new Patient(13,"Luna", LocalDate.parse("1997-11-07"),"plo"));

     return patients;
    }

    @Override
    public int add(Patient patient){
        patients.add(patient);
        return 0;
    }

    @Override
    public void update(Patient patient) {
        System.out.println("Patient updated");
    }

    @Override
    public void delete(int idDelete) {
        System.out.println("Patient deleted");
    }

    public Patient get(int id){
        //return patients.stream().findFirst(patient -> patient.getID()==id);
        return null;
    }


}
