package domain.mappers;


import dao.model.Credentials;
import domain.model.CredentialDTO;

public class CredentialDTOMapper {

    public Credentials dtoToEntity(CredentialDTO credentialDTO) {

        return new Credentials(0, credentialDTO.getUsername(),credentialDTO.getPassword());

    }

    public CredentialDTO entityToDto(Credentials credentials) {
        return new CredentialDTO(credentials.getUsername(),credentials.getPassword());
    }
}
