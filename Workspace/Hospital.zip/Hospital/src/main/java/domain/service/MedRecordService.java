package domain.service;

import dao.model.MedRecord;
import dao.repositories.JDBCDoctorRepository;
import dao.repositories.JDBCMedRecordRepository;
import domain.mappers.DoctorDTOMapper;
import domain.mappers.MedRecordDTOMapper;
import domain.model.DoctorDTO;
import domain.model.MedRecordDTO;
import jakarta.inject.Inject;

import java.util.List;
import java.util.stream.Collectors;

public class MedRecordService {
    private final JDBCMedRecordRepository medRecordRepository;
    private final MedRecordDTOMapper medRecordDTOMapper;

    @Inject
    public MedRecordService(JDBCMedRecordRepository medRecordRepository, MedRecordDTOMapper medRecordDTOMapper){
        this.medRecordRepository = medRecordRepository;
        this.medRecordDTOMapper = medRecordDTOMapper;
    }

    public List<MedRecordDTO> getAllbyPatientId(int patientId){
        return medRecordRepository.getAllbyPatientId(patientId).stream().map(medRecordDTOMapper::entityToDto).collect(Collectors.toList());
    }

    public void add(MedRecordDTO medRecordDTO){
        medRecordRepository.add(medRecordDTOMapper.dtoToEntity(medRecordDTO));
    }

    public void update(MedRecordDTO medRecordDTO){medRecordRepository.update(medRecordDTOMapper.dtoToEntity(medRecordDTO));}

    public void delete(int idDelete){medRecordRepository.delete(idDelete);}
}
