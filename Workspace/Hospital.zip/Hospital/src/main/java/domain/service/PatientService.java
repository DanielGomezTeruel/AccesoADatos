package domain.service;

import dao.repositories.JDBCPatientRepository;
import domain.mappers.PatientDTOMapper;
import domain.model.PatientDTO;
import jakarta.inject.Inject;

import java.util.List;
import java.util.stream.Collectors;

public class PatientService {
    private final JDBCPatientRepository patientRepository;
    private final PatientDTOMapper patientDTOMapper;

    @Inject
    public PatientService(JDBCPatientRepository patientRepository, PatientDTOMapper patientDTOMapper){
        this.patientRepository = patientRepository;
        this.patientDTOMapper = patientDTOMapper;
    }
    public List<PatientDTO> getAll(){
        return patientRepository.getAll().stream().map(patientDTOMapper::entityToDto).collect(Collectors.toList());
    }

    public void add(PatientDTO patientDTO){
        patientRepository.add(patientDTOMapper.dtoToEntity(patientDTO));
    }

    public void update(PatientDTO patientDTO){patientRepository.update(patientDTOMapper.dtoToEntity(patientDTO));}

    public void delete(int idDelete){patientRepository.delete(idDelete);}
}
