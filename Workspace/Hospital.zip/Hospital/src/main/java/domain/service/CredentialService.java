package domain.service;


import dao.CredentialRepository;
import jakarta.inject.Inject;

public class CredentialService {
    private final CredentialRepository credentialRepository;

    @Inject
    public CredentialService(CredentialRepository credentialRepository){
        this.credentialRepository=credentialRepository;
    }
}
