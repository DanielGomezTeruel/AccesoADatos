package org.hospitalspring2dam.dao.mappers;



import org.hospitalspring2dam.dao.model.Credential;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import java.sql.ResultSet;
import java.sql.SQLException;



@Component
public class CredentialsSQLMapper implements RowMapper<Credential> {

    @Override
    public Credential mapRow(ResultSet rs, int rowNum) throws SQLException {
        Credential credential = new Credential();
        credential.setId(rs.getInt("user_id"));
        credential.setUsername(rs.getString("username")); // also with indexes: rs.getInt(1)
        credential.setPassword(rs.getString("password")); //also with indexes: rs.getString(2)credentials.add(credential);
        return credential;
    }
}
