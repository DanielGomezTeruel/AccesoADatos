package org.hospitalspring2dam.dao;

public interface AppointmentRepository {
    void deleteByPatient(int idDelete);

    void deleteByDoctor(int idDelete);
}
