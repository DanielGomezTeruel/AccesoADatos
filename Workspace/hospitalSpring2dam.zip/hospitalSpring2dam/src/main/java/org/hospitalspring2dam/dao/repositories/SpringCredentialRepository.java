package org.hospitalspring2dam.dao.repositories;


import org.hospitalspring2dam.dao.CredentialRepository;
import org.hospitalspring2dam.dao.common.SQLQueries;
import org.hospitalspring2dam.dao.mappers.CredentialsSQLMapper;
import org.hospitalspring2dam.dao.model.Credential;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

@Repository
public class SpringCredentialRepository implements CredentialRepository {


    private final CredentialsSQLMapper credentialsSQLMapper;
    private final JdbcClient jdbcClient;

    public SpringCredentialRepository(CredentialsSQLMapper credentialsSQLMapper, JdbcClient jdbcClient) {
        this.credentialsSQLMapper = credentialsSQLMapper;
        this.jdbcClient = jdbcClient;
    }

    @Override
    public Credential getByUsername(String username) {
        return jdbcClient.sql(SQLQueries.SELECT_getCredentials_QUERY)
                .param("username", username)
                .query(credentialsSQLMapper)
                .single();

    }


    @Override
    public void addPatientCredential(Credential credential, int patient_id) {
        jdbcClient.sql(SQLQueries.INSERT_patient_credentials)
                .param("username", credential.getUsername())
                .param("password", credential.getPassword())
                .param("patient_id", patient_id)
                .update();
    }

    @Override
    public void addDoctorCredential(Credential credential, int doctor_id) {
        jdbcClient.sql(SQLQueries.INSERT_doctor_credentials)
                .param("username", credential.getUsername())
                .param("password", credential.getPassword())
                .param("doctor_id", doctor_id)
                .update();
    }

    @Override
    public void update(Credential credentialDatabase) {

    }

    @Override
    public void deleteByPatient(int patient_id) {
        jdbcClient.sql(SQLQueries.DELETE_patient_cred)
                .param("patient_id", patient_id)
                .update();
    }

    @Override
    public void deleteByDoctor(int doctor_id) {
        jdbcClient.sql(SQLQueries.DELETE_doctor_cred)
                .param("doctor_id", doctor_id)
                .update();
    }
}
