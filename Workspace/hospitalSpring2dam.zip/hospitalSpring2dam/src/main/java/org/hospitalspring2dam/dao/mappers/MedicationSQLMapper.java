package org.hospitalspring2dam.dao.mappers;

import org.hospitalspring2dam.dao.model.Medication;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class MedicationSQLMapper implements RowMapper<Medication> {

    @Override
    public Medication mapRow(ResultSet rs, int rowNum) throws SQLException {
        Medication medication = new Medication();
        medication.setPrescription_id(rs.getInt("prescription_id"));
        medication.setRecord_id(rs.getInt("record_id"));
        medication.setName(rs.getString("medication_name"));
        medication.setDosage(rs.getString("dosage"));
        return medication;
    }
}
