package org.hospitalspring2dam.dao.repositories;


import org.hospitalspring2dam.dao.AppointmentRepository;
import org.hospitalspring2dam.dao.CredentialRepository;
import org.hospitalspring2dam.dao.DoctorRepository;
import org.hospitalspring2dam.dao.MedRecordRepository;
import org.hospitalspring2dam.dao.common.SQLQueries;
import org.hospitalspring2dam.dao.mappers.DoctorSQLMapper;
import org.hospitalspring2dam.dao.model.Doctor;
import org.hospitalspring2dam.domain.exceptions.ForeignKeyException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class SpringDoctorRepository implements DoctorRepository {


    private final DoctorSQLMapper doctorSQLMapper;
    private final JdbcClient jdbcClient;
    private final CredentialRepository credentialRepository;
    private final AppointmentRepository appointmentRepository;
    private final MedRecordRepository medRecordRepository;


    public SpringDoctorRepository(
            DoctorSQLMapper doctorSQLMapper,
            JdbcClient jdbcClient,
            CredentialRepository credentialRepository,
            AppointmentRepository appointmentRepository,
            MedRecordRepository medRecordRepository
    ) {
        this.doctorSQLMapper = doctorSQLMapper;
        this.jdbcClient = jdbcClient;
        this.credentialRepository = credentialRepository;
        this.appointmentRepository = appointmentRepository;
        this.medRecordRepository = medRecordRepository;
    }

    @Override
    public List<Doctor> getAll() {
        return jdbcClient
                .sql(SQLQueries.SELECT_doctors_QUERY)
                .query(doctorSQLMapper).list();
    }

    @Override
    @Transactional
    public int add(Doctor doctor) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcClient.sql(SQLQueries.INSERT_doctor)
                .param("name", doctor.getName())
                .param("specialization", doctor.getSpecialization())
                .param("phone", doctor.getPhone())
                .update(keyHolder);

        credentialRepository.addDoctorCredential(doctor.getCredential(), keyHolder.getKey().intValue());

        return keyHolder.getKey().intValue();
    }

    @Override
    public void update(Doctor doctor) {
        jdbcClient.sql(SQLQueries.UPDATE_DOCTOR)
                .param("doctor_id", doctor.getId())
                .param("name", doctor.getName())
                .param("specialization", doctor.getSpecialization())
                .param("phone", doctor.getPhone())
                .update();
    }

    @Override
    public void delete(int idDelete, boolean answer) {

        appointmentRepository.deleteByDoctor(idDelete);
        credentialRepository.deleteByDoctor(idDelete);
        if (answer) {
            medRecordRepository.deleteByDoctor(idDelete);
        }
        try {
            jdbcClient.sql(SQLQueries.DELETE_doctor).param("doctor_id", idDelete);
        } catch (DataIntegrityViolationException e) {
            throw new ForeignKeyException("Doctor deletion incomplete");
        }
    }
}
