package org.hospitalspring2dam.dao.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Medication {
    private int prescription_id;
    private int record_id;
    private String name;
    private String dosage;
}
