package org.hospitalspring2dam.dao.repositories;

import org.hospitalspring2dam.dao.MedicationRepository;
import org.hospitalspring2dam.dao.common.SQLQueries;
import org.hospitalspring2dam.dao.mappers.MedicationSQLMapper;
import org.hospitalspring2dam.dao.model.Medication;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SpringMedicationRepository implements MedicationRepository {


    private final MedicationSQLMapper medicationSQLMapper;
    private final JdbcClient jdbcClient;


    public SpringMedicationRepository(
            MedicationSQLMapper medicationSQLMapper,
            JdbcClient jdbcClient
    ) {
        this.medicationSQLMapper = medicationSQLMapper;
        this.jdbcClient = jdbcClient;
    }


    @Override
    public List<Medication> getAll() {
        return jdbcClient
                .sql(SQLQueries.SELECT_allMedications_QUERY)
                .query(medicationSQLMapper)
                .list();
    }

    @Override
    public List<Medication> getAllByMedRecord(int record_id) {

        return jdbcClient
                .sql(SQLQueries.SELECT_getMedicationsByMedRecord_QUERY)
                .param("record_id", record_id)
                .query(medicationSQLMapper).list();

    }

    @Override
    public int add(Medication medication) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcClient.sql(SQLQueries.INSERT_medRecord)
                .param("record_id", medication.getRecord_id())
                .param("medication_name", medication.getName())
                .param("dosage", medication.getDosage())
                .update(keyHolder);

        return keyHolder.getKey().intValue();
    }

    @Override
    public int add(int record_id, String medication) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcClient.sql(SQLQueries.INSERT_medications)
                .param("record_id", record_id)
                .param("medication_name", medication)
                .update(keyHolder);

        return keyHolder.getKey().intValue();
    }


    @Override
    public void deleteByMedRecord(int idDelete) {
        jdbcClient.sql(SQLQueries.DELETE_medRecord_medications)
                .param("record_id", idDelete)
                .update();
    }

    @Override
    public void deleteByPatient(int idDelete) {
        jdbcClient.sql(SQLQueries.DELETE_patient_medications)
                .param("patient_id", idDelete)
                .update();
    }

    @Override
    public void deleteByDoctor(int idDelete) {
        jdbcClient.sql(SQLQueries.DELETE_doctor_medications)
                .param("doctor_id", idDelete)
                .update();
    }


}
