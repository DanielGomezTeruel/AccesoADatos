package org.hospitalspring2dam.dao.repositories;

import org.hospitalspring2dam.dao.PaymentRepository;
import org.hospitalspring2dam.dao.common.SQLQueries;
import org.hospitalspring2dam.dao.mappers.PaymentSQLMapper;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

@Repository
public class SpringPaymentRepository implements PaymentRepository {

    private final JdbcClient jdbcClient;
    private final PaymentSQLMapper paymentSQLMapper;

    public SpringPaymentRepository(
            JdbcClient jdbcClient,
            PaymentSQLMapper paymentSQLMapper
    ) {
        this.jdbcClient = jdbcClient;
        this.paymentSQLMapper = paymentSQLMapper;
    }


    @Override
    public double getAllByPatient(int idPatient) {
        return jdbcClient
                .sql(SQLQueries.SELECT_allPatientPayments_QUERY)
                .param("patient_id", idPatient)
                .query(paymentSQLMapper)
                .single();
    }

    @Override
    public void deleteByPatient(int idDelete) {
        jdbcClient.sql(SQLQueries.DELETE_patient_payments)
                .param("patient_id", idDelete)
                .update();
    }
}
