package org.hospitalspring2dam.dao.repositories;


import org.hospitalspring2dam.dao.MedRecordRepository;
import org.hospitalspring2dam.dao.MedicationRepository;
import org.hospitalspring2dam.dao.common.SQLQueries;
import org.hospitalspring2dam.dao.mappers.MedRecordSQLMapper;
import org.hospitalspring2dam.dao.model.MedRecord;
import org.hospitalspring2dam.dao.model.Medication;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class SpringMedRecordRepository implements MedRecordRepository {

    private final MedRecordSQLMapper medRecordSQLMapper;
    private final MedicationRepository medicationRepository;
    private final JdbcClient jdbcClient;


    public SpringMedRecordRepository(
            MedRecordSQLMapper medRecordSQLMapper,
            MedicationRepository medicationRepository,
            JdbcClient jdbcClient
    ) {
        this.medRecordSQLMapper = medRecordSQLMapper;
        this.medicationRepository = medicationRepository;
        this.jdbcClient = jdbcClient;
    }

    @Override
    public List<MedRecord> getAllbyPatientId(int idPatient) {
        List<MedRecord> records = jdbcClient
                .sql(SQLQueries.SELECT_getMedRecordsById_QUERY)
                .param("patient_id", idPatient)
                .query(medRecordSQLMapper)
                .list();
        records.forEach(record -> {
            record.setMedications(medicationRepository
                    .getAllByMedRecord(record.getId())
                    .stream()
                    .map(Medication::getName)
                    .toList());
        });

        return records;
    }

    @Override
    @Transactional
    public int add(MedRecord medRecord) {

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcClient.sql(SQLQueries.INSERT_medRecord)
                .param("patient_id", medRecord.getPatientID())
                .param("doctor_id", medRecord.getDoctorID())
                .param("diagnosis", medRecord.getDiagnosis())
                .param("admission_date", medRecord.getAdmission_date())
                .update(keyHolder);

        medRecord
                .getMedications()
                .forEach(medication -> medicationRepository.add(keyHolder.getKey().intValue(), medication));

        return keyHolder.getKey().intValue();
    }

    @Override
    @Transactional
    public void update(MedRecord medRecord) {
        jdbcClient.sql(SQLQueries.UPDATE_MEDRECORD)
                .param("doctor_id", medRecord.getDoctorID())
                .param("patient_id", medRecord.getPatientID())
                .param("diagnosis", medRecord.getDiagnosis())
                .param("admission_date", medRecord.getAdmission_date())
                .param("record_id", medRecord.getId())
                .update();

        jdbcClient.sql(SQLQueries.DELETE_medRecord_medications)
                .param("record_id", medRecord.getId())
                .update();

        medRecord
                .getMedications()
                .forEach(medication -> medicationRepository.add(medRecord.getId(), medication));

    }

    @Override
    @Transactional
    public void delete(int idDelete) {
        medicationRepository.deleteByMedRecord(idDelete);
        jdbcClient.sql(SQLQueries.DELETE_medRecord)
                .param("record_id", idDelete)
                .update();
    }

    @Override
    @Transactional
    public void deleteByPatient(int idDelete) {
        medicationRepository.deleteByPatient(idDelete);
        jdbcClient.sql(SQLQueries.DELETE_patient_medRecords)
                .param("patient_id", idDelete)
                .update();
    }

    @Override
    @Transactional
    public void deleteByDoctor(int idDelete) {
        medicationRepository.deleteByDoctor(idDelete);
        jdbcClient.sql(SQLQueries.DELETE_doctor_medRecords)
                .param("doctor_id", idDelete)
                .update();
    }
}
