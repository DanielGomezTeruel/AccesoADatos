package org.hospitalspring2dam.domain.mappers;


import org.hospitalspring2dam.dao.model.Credential;
import org.hospitalspring2dam.dao.model.Patient;
import org.hospitalspring2dam.domain.model.PatientDTO;
import org.springframework.stereotype.Component;

@Component
public class PatientDTOMapper {

    public Patient dtoToEntity(PatientDTO patientDTO) {

        return new Patient(patientDTO.getId(), patientDTO.getName(), patientDTO.getBirthDate(), patientDTO.getPhone(), new Credential(0, patientDTO.getCredentials().getUsername(), patientDTO.getCredentials().getPassword()));

    }

    public PatientDTO entityToDto(Patient patient, double paid) {
        return new PatientDTO(patient.getId(), patient.getName(),
                patient.getBirthDate(), patient.getPhone(), paid, patient.getCredential().getUsername(), patient.getCredential().getPassword());
    }

}
