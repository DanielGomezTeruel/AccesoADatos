package org.hospitalspring2dam.domain.service;


import org.hospitalspring2dam.dao.CredentialRepository;
import org.hospitalspring2dam.domain.model.CredentialDTO;
import org.springframework.stereotype.Service;

@Service
public class CredentialService {
    private final CredentialRepository credentialRepository;



    public CredentialService(CredentialRepository credentialRepository) {
        this.credentialRepository = credentialRepository;
    }

    public boolean login(CredentialDTO credentialDTO) {
        return credentialRepository.getByUsername(credentialDTO.getUsername()) != null && credentialDTO.getPassword().equals(credentialRepository.getByUsername(credentialDTO.getUsername()).getPassword());
    }
}
