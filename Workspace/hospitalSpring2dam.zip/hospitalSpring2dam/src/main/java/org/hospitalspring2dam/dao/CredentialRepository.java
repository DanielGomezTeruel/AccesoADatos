package org.hospitalspring2dam.dao;


import org.hospitalspring2dam.dao.model.Credential;

public interface CredentialRepository {
    Credential getByUsername(String username);

    void addPatientCredential(Credential credential, int patient_id);

    void addDoctorCredential(Credential credential, int doctor_id);

    void update(Credential credentialDatabase);

    void deleteByPatient(int idDelete);

    void deleteByDoctor(int idDelete);
}
