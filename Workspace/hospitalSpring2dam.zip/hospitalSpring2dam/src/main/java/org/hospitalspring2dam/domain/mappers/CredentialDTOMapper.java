package org.hospitalspring2dam.domain.mappers;

import org.hospitalspring2dam.dao.model.Credential;
import org.hospitalspring2dam.domain.model.CredentialDTO;
import org.springframework.stereotype.Component;

@Component
public class CredentialDTOMapper {

    public Credential dtoToEntity(CredentialDTO credentialDTO) {

        return credentialDTO==null?null:new Credential(0, credentialDTO.getUsername(),credentialDTO.getPassword());

    }

    public CredentialDTO entityToDto(Credential credential) {
        return credential ==null?null:new CredentialDTO(credential.getUsername(), credential.getPassword());
    }
}
