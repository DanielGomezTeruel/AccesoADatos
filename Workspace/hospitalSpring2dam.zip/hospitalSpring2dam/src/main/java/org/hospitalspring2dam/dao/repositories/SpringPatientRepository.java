package org.hospitalspring2dam.dao.repositories;


import org.hospitalspring2dam.dao.*;
import org.hospitalspring2dam.dao.common.SQLQueries;
import org.hospitalspring2dam.dao.mappers.PatientSQLMapper;
import org.hospitalspring2dam.dao.model.Patient;
import org.hospitalspring2dam.domain.exceptions.ForeignKeyException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.util.List;

@Repository
public class SpringPatientRepository implements PatientRepository {

    private final PatientSQLMapper patientSQLMapper;
    private final JdbcClient jdbcClient;
    private final CredentialRepository credentialRepository;
    private final MedRecordRepository medRecordRepository;
    private final PaymentRepository paymentRepository;
    private final AppointmentRepository appointmentRepository;


    public SpringPatientRepository(
            PatientSQLMapper patientSQLMapper,
            JdbcClient jdbcClient,
            CredentialRepository credentialRepository,
            MedRecordRepository medRecordRepository,
            PaymentRepository paymentRepository,
            AppointmentRepository appointmentRepository
    ) {
        this.patientSQLMapper = patientSQLMapper;
        this.jdbcClient = jdbcClient;
        this.credentialRepository = credentialRepository;
        this.medRecordRepository = medRecordRepository;
        this.paymentRepository = paymentRepository;
        this.appointmentRepository = appointmentRepository;
    }

    @Override
    public List<Patient> getAll() {
        return jdbcClient
                .sql(SQLQueries.SELECT_patients_QUERY)
                .query(patientSQLMapper).list();
    }

    @Override
    @Transactional
    public int add(Patient patient) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcClient.sql(SQLQueries.INSERT_patient)
                .param("name", patient.getName())
                .param("date_of_birth", patient.getBirthDate())
                .param("phone", patient.getPhone())
                .update(keyHolder);

        credentialRepository.addPatientCredential(patient.getCredential(), keyHolder.getKey().intValue());

        return keyHolder.getKey().intValue();
    }

    @Override
    public void update(Patient patient) {
        jdbcClient.sql(SQLQueries.UPDATE_PATIENT)
                .param("name", patient.getName())
                .param("date_of_birth", Date.valueOf(patient.getBirthDate()))
                .param("phone", patient.getPhone())
                .param("patient_id", patient.getId())
                .update();
    }

    @Override
    @Transactional
    public void delete(int idDelete, boolean answer) {
        paymentRepository.deleteByPatient(idDelete);
        appointmentRepository.deleteByPatient(idDelete);
        credentialRepository.deleteByPatient(idDelete);
        if (answer) {
            medRecordRepository.deleteByPatient(idDelete);
        }
        try {
            jdbcClient.sql(SQLQueries.DELETE_patient)
                    .param("patient_id", idDelete)
                    .update();
        } catch (DataIntegrityViolationException e) {
            throw new ForeignKeyException("There are medical records associated with this patient. Are you sure you want to delete?");
        }
    }

    public Patient get(int id) {
        return getAll().stream().filter(patient -> patient.getId() == id).findFirst().orElse(null);
    }
}
