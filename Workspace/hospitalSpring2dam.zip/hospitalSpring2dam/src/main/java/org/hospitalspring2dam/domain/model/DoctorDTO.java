package org.hospitalspring2dam.domain.model;

import lombok.*;

@Data
@AllArgsConstructor
public class DoctorDTO {
    private int id;
    private String name;
    private CredentialDTO credentials;

    public DoctorDTO(int id, String name, String username, String password) {
        this.id = id;
        this.name = name;
        this.credentials = new CredentialDTO(username, password);
    }
}
