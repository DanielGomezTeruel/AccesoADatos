package org.hospitalspring2dam.domain.service;

import org.hospitalspring2dam.dao.MedicationRepository;
import org.hospitalspring2dam.dao.model.Medication;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedicationsService {
    private final MedicationRepository medicationRepository;

    public MedicationsService(MedicationRepository medicationRepository) {
        this.medicationRepository = medicationRepository;
    }

    public List<String> getAll() {
        return medicationRepository.getAll()
                .stream()
                .map(Medication::getName)
                .toList();
    }
}
