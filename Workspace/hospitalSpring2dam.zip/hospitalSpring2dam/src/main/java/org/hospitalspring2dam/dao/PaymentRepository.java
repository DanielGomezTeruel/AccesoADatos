package org.hospitalspring2dam.dao;


public interface PaymentRepository {

    double getAllByPatient(int idPatient);

    void deleteByPatient(int idDelete);
}
