package org.hospitalspring2dam.dao.mappers;


import org.hospitalspring2dam.dao.model.Credential;
import org.hospitalspring2dam.dao.model.Doctor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class DoctorSQLMapper implements RowMapper<Doctor> {
    @Override
    public Doctor mapRow(ResultSet rs, int rowNum) throws SQLException {
        Doctor doctor = new Doctor();
        doctor.setId(rs.getInt("doctor_id")); // also with indexes: rs.getInt(1)
        doctor.setName(rs.getString("name")); //also with indexes: rs.getString(2)
        doctor.setSpecialization(rs.getString("specialization"));
        doctor.setPhone(rs.getString("phone"));
        doctor.setCredential(new Credential(rs.getInt("doctor_id"),null, null));
        return doctor;
    }
}
