package org.hospitalspring2dam.dao.mappers;


import org.hospitalspring2dam.dao.model.MedRecord;
import org.jspecify.annotations.Nullable;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;


@Component
public class MedRecordSQLMapper implements RowMapper<MedRecord> {

    @Override
    public MedRecord mapRow(ResultSet rs, int rowNum) throws SQLException {
        MedRecord record=new MedRecord();
        record.setId(rs.getInt("record_id"));
        record.setPatientID(rs.getInt("patient_id"));
        record.setDoctorID(rs.getInt("doctor_id"));
        record.setDiagnosis(rs.getString("diagnosis"));
        record.setAdmission_date(rs.getDate("admission_date").toLocalDate());
        return record;
    }
}